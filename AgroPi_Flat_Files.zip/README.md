# AgroPi Project
AI-powered agricultural automation system.