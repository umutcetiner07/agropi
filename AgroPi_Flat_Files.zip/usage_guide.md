# How to Use AgroPi
Instructions on deploying and operating AgroPi.