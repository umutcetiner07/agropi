# System Architecture
Backend, frontend, AI, and sensor integration.